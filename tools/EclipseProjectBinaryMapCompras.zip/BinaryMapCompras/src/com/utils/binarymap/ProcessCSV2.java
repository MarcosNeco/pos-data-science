package com.utils.binarymap;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class ProcessCSV2 {

	private static final String DATA_INPUT = "M:\\MassiveFiles\\UniRitter\\Machine Learning I\\TrabalhoFinal\\meta_Video_Games.csv";
	
	private static final String BINARY_MATRIX_FILE_OUTPUT_PATH = "M:\\MassiveFiles\\UniRitter\\Machine Learning I\\TrabalhoFinal\\exportings\\meta_Video_GamesBinaryMatrix.csv";
	
	int count = 0;
	
	private List<String> listProdutos;
	
	public static void main(String[] args) {
		new ProcessCSV2().process();
	}
	
	private List<Set<String>> carregarLinhas() {
		Stream<String> linhas = null;
		Path dataInput = Paths.get(DATA_INPUT);
		
		try {
			linhas = Files.lines(dataInput, StandardCharsets.ISO_8859_1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Carregando linhas...");
		List<Set<String>> linhasHash = new ArrayList<Set<String>>();
		linhas.forEach(linha -> {
			Set<String> linhaHash = new HashSet(Arrays.asList(linha.split(";")));
			linhaHash.retainAll(listProdutos);
			linhasHash.add(linhaHash);
		});
		
		return linhasHash;
	}
	
	private void gravarCabecalho(List<String> listProdutos, Path binaryMatrixFile) {
		try {
			Files.write(binaryMatrixFile, (montaCabecalho(listProdutos) + "\n").getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void process() {
		Path binaryMatrixFile = Paths.get(BINARY_MATRIX_FILE_OUTPUT_PATH);
		StringBuilder sb = new StringBuilder();
		String values[] = {"0;".intern(), "1;".intern()};
		String nl = "\n".intern();
		
		listProdutos = getAsins();
		List<Set<String>> linhasHash = carregarLinhas();

		gravarCabecalho(listProdutos, binaryMatrixFile);
		
		System.out.println("Gerando arquivo CSV...");
		linhasHash.forEach(linhaHash -> {
			listProdutos.forEach(produto -> {
				sb.append(linhaHash.contains(produto) ? values[1] : values[0]);
			});
			
			sb.deleteCharAt(sb.length() - 1);
			sb.append(nl);
			count++;
			
			if (count % 1000 == 0) {
				try {
					Files.write(binaryMatrixFile, sb.toString().getBytes(), StandardOpenOption.APPEND);
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println(count);
				sb.delete(0, sb.length());
			}
		});
		
		if (sb.length() > 0) {
			try {
				Files.write(binaryMatrixFile, sb.toString().getBytes(), StandardOpenOption.APPEND);
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println(count);
		}
		
		System.out.println("Arquivo gerado.");
	}
	
	private List<String> getAsins() {
		Path dataInput = Paths.get(DATA_INPUT);
		List<String> asins = new ArrayList<String>();
		
		System.out.println("Buscando produtos...");
		try {
			Files.lines(dataInput, StandardCharsets.ISO_8859_1).forEach(linha -> {
				asins.add(linha.split(";")[0]);
			});
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return asins;
	}
	
	private String montaCabecalho(List<String> listProdutos) {
		StringBuilder cabecalho = new StringBuilder();
		
		listProdutos.forEach(asin -> {
			cabecalho.append(asin + ';');
		});
		
		cabecalho.deleteCharAt(cabecalho.length() - 1);
		
		return cabecalho.toString();
	}
}
